import os
import cv2
from deepface import DeepFace
import numpy as np

# --- 1. PFADKONFIGURATION ---
INPUT_DIR = "/data/input"
OUTPUT_DIR = "/data/output" 

# Bild finden
IMAGE_FILENAME = None
for filename in os.listdir(INPUT_DIR):
    if filename.lower().endswith(('.jpg', '.jpeg', '.png')):
        IMAGE_FILENAME = filename
        break

if not IMAGE_FILENAME:
    print(f"DEEPFACE: FEHLER: Im Ordner '{INPUT_DIR}' kein Bild gefunden.")
    print("Stellen Sie sicher, dass das Bild im lokalen Ordner local_input/ liegt und der Bind-Mount korrekt ist.")
    exit()

img_path = os.path.join(INPUT_DIR, IMAGE_FILENAME)
# Finaler Output-Pfad im gemounteten Output-Ordner
output_path = os.path.join(OUTPUT_DIR, f"deepface_analyzed_{IMAGE_FILENAME}") 
print(f"DEEPFACE: Starte Analyse für {IMAGE_FILENAME}...")

# --- 2. DEEPFACE ANALYSE ---
try:
    results = DeepFace.analyze(
        img_path=img_path,
        actions=["age", "gender", "emotion"],
        detector_backend="opencv",
        enforce_detection=False
    )
except Exception as e:
    print(f"DEEPFACE: FEHLER bei DeepFace.analyze: {e}")
    exit()

if isinstance(results, dict):
    results = [results]

img = cv2.imread(img_path)
if img is None:
    print(f"DEEPFACE: FEHLER: Bild '{IMAGE_FILENAME}' konnte nicht geladen werden.")
    exit()

# --- 3. BILD BESCHRIFTEN (DEEPFACE) ---
for r in results:
    region = r["region"]
    x, y, w, h = int(region["x"]), int(region["y"]), int(region["w"]), int(region["h"])
    age = r["age"]
    gender = r["dominant_gender"]
    emotion = r["dominant_emotion"]
    line1 = f"{gender}, {age}"
    line2 = f"{emotion}"

    # Zeichenlogik (vereinfacht)
    cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
    font = cv2.FONT_HERSHEY_SIMPLEX
    scale = 0.6
    thickness = 2
    
    # Text-Hintergrund für bessere Sichtbarkeit
    (w1, h1), _ = cv2.getTextSize(line1, font, scale, thickness)
    (w2, h2), _ = cv2.getTextSize(line2, font, scale, thickness)
    tw = max(w1, w2)
    th = h1 + h2 + 6
    tx = x
    
    top_left = (tx - 4, y - 12 - th) 
    bottom_right = (tx + tw + 4, y - 12 + 4) 
    
    cv2.rectangle(img, top_left, bottom_right, (0, 0, 0), -1)
    cv2.putText(img, line1, (tx, y - 12 - th + 18), font, scale, (0, 255, 0), thickness, cv2.LINE_AA)
    cv2.putText(img, line2, (tx, y - 12 + 2), font, scale, (0, 255, 0), thickness, cv2.LINE_AA)


# --- 4. OUTPUT IN DEN LOKALEN ORDNER SCHREIBEN ---
cv2.imwrite(output_path, img)
print(f"DEEPFACE: Analyse abgeschlossen. Beschriftetes Bild gespeichert in: {output_path} (Ihr local_output Ordner)")