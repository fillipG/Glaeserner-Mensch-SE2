import os
import cv2
import numpy as np
from PIL import Image
from ultralytics import YOLO

# --- KONFIGURATION ---
img_path = "fittosize__968_0_417689582c4f431f9786d60b8c0ea111_fotolia_115546816_s.jpg"
output_dir = "output"

# GrabCut/Post-Processing Parameter
CROP_PADDING_FACTOR = 1.4
GC_RECT_STRENGTH = 0.05
GC_ITERATIONS = 8
KERNEL_SIZE = 5
BLUR_SIZE = 7

# Sicherstellen, dass der Output-Ordner existiert
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Modell laden
model = YOLO("yolov8n-face.pt")

# Bild laden
img = cv2.imread(img_path)

if img is None:
    print(f"FEHLER: Datei '{img_path}' nicht gefunden!")
    print("Inhalt des aktuellen Verzeichnisses:", os.listdir("."))
    exit()

# Analyse starten
print("Starte Gesichtserkennung...")
results = model(img)[0]

for i, box in enumerate(results.boxes):
    x1, y1, x2, y2 = map(int, box.xyxy[0])

    # Zuschneidebereich berechnen
    w, h = x2 - x1, y2 - y1
    side = int(max(w, h) * CROP_PADDING_FACTOR)
    cx, cy = x1 + w // 2, y1 + h // 2

    x1_c = max(0, cx - side // 2)
    y1_c = max(0, cy - side // 2)
    x2_c = min(img.shape[1], cx + side // 2)
    y2_c = min(img.shape[0], cy + side // 2)

    crop = img[y1_c:y2_c, x1_c:x2_c]

    # GrabCut Algorithmus
    mask = np.zeros(crop.shape[:2], np.uint8)
    bgdModel = np.zeros((1, 65), np.float64)
    fgdModel = np.zeros((1, 65), np.float64)

    h_c, w_c = crop.shape[:2]
    margin = int(min(w_c, h_c) * GC_RECT_STRENGTH)
    rect = (margin, margin, w_c - 2 * margin, h_c - 2 * margin)

    cv2.grabCut(crop, mask, rect, bgdModel, fgdModel, GC_ITERATIONS, cv2.GC_INIT_WITH_RECT)
    mask2 = np.where((mask == cv2.GC_FGD) | (mask == cv2.GC_PR_FGD), 255, 0).astype("uint8")

    # Kanten glätten
    kernel = np.ones((KERNEL_SIZE, KERNEL_SIZE), np.uint8)
    mask2 = cv2.morphologyEx(mask2, cv2.MORPH_CLOSE, kernel)
    mask2 = cv2.GaussianBlur(mask2, (BLUR_SIZE, BLUR_SIZE), 0)

    # Transparenz hinzufügen (RGBA)
    rgba = cv2.cvtColor(crop, cv2.COLOR_BGR2RGBA)
    rgba[:, :, 3] = mask2

    # Speichern
    file_name = f"face_{i+1}.png"
    save_path = os.path.join(output_dir, file_name)
    Image.fromarray(rgba).save(save_path)
    print(f"Gespeichert: {save_path}")

print("Fertig! Alle Gesichter wurden im Ordner 'output' gespeichert.")